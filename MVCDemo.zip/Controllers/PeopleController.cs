﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCDemo.Controllers
{
    public class PeopleController : Controller
    {
        // GET: People
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ListPeople()
        {
            List<Models.PersonModel> people = new List<Models.PersonModel>();

            people.Add(new Models.PersonModel { FirstName = "Tim", LastName = "Corey", Age = 38 });
            people.Add(new Models.PersonModel { FirstName = "Joe", LastName = "Smith", Age = 56 });
            people.Add(new Models.PersonModel { FirstName = "Sarah", LastName = "Connor", Age = 25 });

            return View(people);
        }
    }
}